from selenium.webdriver import ActionChains
from features.browser import Browser


class OrderItem(Browser):
    # locators for sign in
    click_SignIn_xpath = '/html//header[@id="header"]//nav//a[@title="Log in to your customer account"]'
    enter_email_id = "email"
    enter_password_id = "passwd"
    click_signIn_id = "SubmitLogin"
    click_emptyCart_xpath = "//span[contains(text(),'(empty)')]"
    emptyBasket_xpath = "//p[contains(text(),'Your shopping cart is empty.')]"
    search_items_id = "search_query_top"
    click_searchButton_name = "submit_search"
    select_item_xpath = "//div[@id='center_column']/ul//div[@class='product-container']//div[@class='product-image-container'][1]"
    click_addToCart_xpath = "//p[@id='add_to_cart']//span[.='Add to cart']"
    mouseHover_xpath = "//a[@title = 'View my shopping cart']"
    click_continueShopping_xpath = "//span[@title='Continue shopping']"
    click_accountInfo_xpath = "//a[@title = 'View my customer account']"
    click_myPersonalInfo_xpath = "//span[contains(text(),'My personal information')]"
    update_firstName_id = "firstname"
    click_save_name = "submitIdentity"

    def clickOnSignIn(self):
        self.driver.find_element_by_xpath(self.click_SignIn_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "Homepage.png")

    def enter_emailAddress(self, username):
        self.driver.find_element_by_id(self.enter_email_id).send_keys(username)
        self.driver.save_screenshot(".\\screenshots\\" + "enterEmail.png")

    def enter_password(self, password):
        self.driver.find_element_by_id(self.enter_password_id).send_keys(password)
        self.driver.save_screenshot(".\\screenshots\\" + "enterPassword.png")

    def clickOnSignInButton(self):
        self.driver.find_element_by_id(self.click_signIn_id).click()
        self.driver.save_screenshot(".\\screenshots\\" + "clickOnSignIn.png")

    def getPageTitle(self):
        title = self.driver.title
        print("Home Page Title:", title)

    def empty_Cart(self, item_number):
        self.driver.find_element_by_xpath(self.click_emptyCart_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "clickOnBasket.png")
        self.driver.find_element_by_xpath(self.emptyBasket_xpath).text
        self.driver.save_screenshot(".\\screenshots\\" + "cartWithZeroItem.png")

    def addItem(self, itemname):
        self.driver.find_element_by_id(self.search_items_id).send_keys(itemname)
        self.driver.find_element_by_name(self.click_searchButton_name).click()
        self.driver.find_element_by_xpath(self.select_item_xpath).click()
        self.driver.find_element_by_xpath(self.click_addToCart_xpath).click()
        self.driver.find_element_by_xpath(self.click_continueShopping_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "continueShopping.png")

    def cartWithItem(self, item_number):
        element = self.driver.find_element_by_xpath(self.mouseHover_xpath)
        actions = ActionChains(self.driver)
        actions.move_to_element(element).perform()
        self.driver.save_screenshot(".\\screenshots\\" + "cartWithOneItem.png")
        element.click()

    def accountInfoPage(self):
        self.driver.find_element_by_xpath(self.click_accountInfo_xpath).click()

    def userClicksOnPersonalInfo(self):
        personalInfoElement = self.driver.find_element_by_xpath(self.click_myPersonalInfo_xpath)
        self.driver.execute_script("arguments[0].click();", personalInfoElement)

    def userUpdateFirstName(self,fname):
        firstname = self.driver.find_element_by_id(self.update_firstName_id).clear()
        firstname.send_keys(fname)

    def userSaveDetails(self):
        saveDetailsElement = self.driver.find_element_by_name(self.click_save_name)
        self.driver.execute_script("arguments[0].click();", saveDetailsElement)
