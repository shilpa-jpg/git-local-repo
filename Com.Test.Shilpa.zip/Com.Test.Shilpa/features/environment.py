from features.browser import Browser
from features.shopping_pages.addItem_pages import OrderItem
from features.utilities.readProperties import ReadConfig


def before_all(context):
    context.browser = Browser()
    context.orderItem = OrderItem()
    context.orderItem.clickOnSignIn()
    username = ReadConfig.getUsername()
    context.orderItem.enter_emailAddress(username)
    password = ReadConfig.getPassword()
    context.orderItem.enter_password(password)
    context.orderItem.clickOnSignInButton
    context.orderItem.getPageTitle()



# def after_all(context):
#     context.amazon_shopping.signOut()
#     context.browser.close()
