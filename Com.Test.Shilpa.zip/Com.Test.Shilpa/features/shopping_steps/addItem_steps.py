from behave import *
from hamcrest import *


@given('the user basket has "{item_number}" items in it')
def basketWithZeroItem(context, item_number):
    context.orderItem.empty_Cart(item_number)
    verify_empty_basket_text = "Your shopping cart is empty."
    assert_that(has_string(verify_empty_basket_text))


@when('the user adds the item to the basket')
def userAddsItem(context):
    context.orderItem.addItem("T-shirts")


@then('the user basket has "{item_number}" items in it')
def CartWithOneItem(context, item_number):
    context.orderItem.cartWithItem(item_number)


@given('user is on account information page')
def userIsOnAccountInfoPage(context):
    context.orderItem.accountInfoPage()


@when('user clicks on my personal information')
def clickOnPersonalInfo(context):
    context.orderItem.userClicksOnPersonalInfo()


@when('And the user update first name')
def updateFirstName(context):
    context.orderItem.userUpdateFirstName("ShilpaC")


@then('the user save details')
def saveDetails(context):
    context.orderItem.userSaveDetails()
